GuppysTailMod = RegisterMod("Case Study - Guppy's Tail", 1)
local mod = GuppysTailMod

table.reduce = function (list, func, init)
    local acc = init
    for k, v in ipairs(list) do
        if 1 == k and not init then
            acc = v
        else
            acc = func(acc, v)
        end
    end
    return acc
end

local f = Font()
f:Load("font/luamini.fnt")

local function removeAll()
    if not Isaac.GetPlayer(0) then return end

    for _,item in ipairs({
    CollectibleType.COLLECTIBLE_GUPPYS_TAIL,
    CollectibleType.COLLECTIBLE_MOMS_KEY,
    CollectibleType.COLLECTIBLE_CONTRACT_FROM_BELOW,
    CollectibleType.COLLECTIBLE_LUCKY_FOOT,
    CollectibleType.COLLECTIBLE_PAY_TO_PLAY}) do

        Isaac.GetPlayer(0):RemoveCollectible(item)
    end

    for _,item in ipairs({
    TrinketType.TRINKET_PAPER_CLIP,
    TrinketType.TRINKET_DAEMONS_TAIL,
    TrinketType.TRINKET_RUSTED_KEY,
    TrinketType.TRINKET_GILDED_KEY}) do

        Isaac.GetPlayer(0):TryRemoveTrinket(item)
    end

    for _,e in ipairs(Isaac.GetRoomEntities()) do
        if e.Type == EntityType.ENTITY_PICKUP then
            e:Remove()
        end
    end

end
removeAll()

local trialMax = 200
local repeatCount = 5

local function def_sprite(anim)
	local spr = Sprite()
	spr:Load(anim)
	spr:Play(spr:GetDefaultAnimation(), true)
	spr:SetFrame(0)
	return spr
end

local textCorpus = ""

local trialNum = trialMax
local currRepeat = 1
local hasTail = false

local EnvNames = {
    CONTROL = 1,
    KEY_ADV = 2,
    MOMS_KEY = 3,
    PAPER_CLIP = 4,
    DAEMONS_TAIL = 5,
    CONTRACT = 6,
    RUSTED_KEY = 7,
    LUCKY_FOOT = 8,
    GILDED_KEY = 9,
    LOTSA_LUCK = 10
}
local EnvText = {
    [EnvNames.CONTROL] = "Control",
    [EnvNames.KEY_ADV] = "Key Advantage",
    [EnvNames.MOMS_KEY] = "Mom's Key",
    [EnvNames.PAPER_CLIP] = "Paper Clip",
    [EnvNames.DAEMONS_TAIL] = "Daemon's Tail",
    [EnvNames.CONTRACT] = "Contract from Below",
    [EnvNames.RUSTED_KEY] = "Rusted Key",
    [EnvNames.LUCKY_FOOT] = "Lucky Foot",
    [EnvNames.GILDED_KEY] = "Gilded Key",
    [EnvNames.LOTSA_LUCK] = "Max Luck",
}

local currentEnv = 1

local centerPos = Vector(Isaac.GetScreenWidth()/2, Isaac.GetScreenHeight()/2)

local getCenter = function()
	return centerPos -- redundant, but elegant :p
end

local function GetPlayers()
    local game = Game()
    local numPlayers = game:GetNumPlayers()

    local players = {}
    for i = 0, numPlayers - 1 do
        local player = Isaac.GetPlayer(i)
        table.insert(players, player)
    end

    return players
end

local ChartType = {
    PIE = 0,
    LINE = 1
}

local disp_chart = ChartType.PIE
local show_chart = true

local room_count = {}

local breakpoints = false
local breaks = {9,20,31,44,55,71,87,102,122,133}

local crust = def_sprite("gfx/guppy/crusts/crust.anm2")
local line = def_sprite("gfx/guppy/line.anm2")
local pixel = def_sprite("gfx/guppy/pixel.anm2")

local pickup_agg = {}
local pickup_keys = {
    ["30-1"] = 0,
    ["20-1"] = 0
}

local name_dict = {

    ["10-1"] = "Full Heart",
    ["10-2"] = "Half Heart",
    ["10-3"] = "Soul Heart",
    ["10-4"] = "Eternal Heart",
    ["10-5"] = "Double Heart",
    ["10-6"] = "Black Heart",
    ["10-7"] = "Golden Heart",
    ["10-8"] = "Half Soul Heart",
    ["10-9"] = "Scared Heart",
    ["10-10"] = "Blended Heart",
    ["10-11"] = "Bone Heart",
    ["10-12"] = "Rotten Heart",

    ["20-1"] = "Penny",
    ["20-2"] = "Nickel",
    ["20-3"] = "Dime",
    ["20-4"] = "Double Penny",
    ["20-5"] = "Lucky Penny",
    ["20-6"] = "Sticky Nickel",
    ["20-7"] = "Golden Coin",

    ["30-1"] = "Key",
    ["30-2"] = "Golden Key",
    ["30-3"] = "Double Key",
    ["30-4"] = "Charged Key",

    ["40-1"] = "Bomb",
    ["40-2"] = "Double Bomb",
    ["40-3"] = "Troll Bomb",
    ["40-4"] = "Golden Bomb",
    ["40-5"] = "Super Troll Bomb",
    ["40-6"] = "Golden Troll Bomb",
    ["40-7"] = "Giga Bomb",

    ["50-0"] = "Chest",
    ["51-0"] = "Bomb Chest",
    ["52-0"] = "Spiked Chest",
    ["53-0"] = "Eternal Chest",
    ["54-0"] = "Mimic Chest",
    ["55-0"] = "Old Chest",
    ["56-0"] = "Wooden Chest",
    ["57-0"] = "Mega Chest",
    ["58-0"] = "Haunted Chest",
    ["60-0"] = "Locked Chest",
    ["69-0"] = "Grab Bag",

    ["50-1"] = "Chest",
    ["51-1"] = "Bomb Chest",
    ["52-1"] = "Spiked Chest",
    ["53-1"] = "Eternal Chest",
    ["54-1"] = "Mimic Chest",
    ["55-1"] = "Old Chest",
    ["56-1"] = "Wooden Chest",
    ["57-1"] = "Mega Chest",
    ["58-1"] = "Haunted Chest",
    ["60-1"] = "Locked Chest",

    ["69-1"] = "Grab Bag",

    ["70-0"] = "Pill",

    ["90-1"] = "Battery",
    ["90-2"] = "Micro Battery",
    ["90-3"] = "Mega Battery",
    ["90-4"] = "Golden Battery",

    ["100-0"] = "Collectible",

    ["300-0"] = "Tarot Card",

    ["340-1"] = "Big Chest",

    ["350-0"] = "Trinket",

    ["360-0"] = "Red Chest",
    ["360-1"] = "Red Chest"
}

local color_dict = {
    [0] = KColor(1,1,1,1),
    [10] = KColor(1,0,0,1),
    [20] = KColor(1,1,0,1),
    [30] = KColor(1,1,1,1),
    [40] = KColor(0.5,0.5,0.5,1),
    [50] = KColor(0.8,0.8,0.5,1),
    [60] = KColor(0,0,1,1),
    [69] = KColor(1,0.5,0,1),
    [70] = KColor(1,0,1,1),
    [90] = KColor(1,1,0,1),
    [100] = KColor(0,1,0,1),
    [300] = KColor(0.47,0.35,0.25,1),
    [350] = KColor(0.5,0.4,1,1),
    [360] = KColor(0.8,0.8,0.5,1),
}

local key_graph = {}

local lumpSum = true
local firstCorrect = 0

local y_scale = 1
local x_scale = 20

function mod:onUpdate()

	if Game().Challenge ~= Isaac.GetChallengeIdByName("Case Study - Guppy's Tail") then return end

end

local function onRender()

    if Game().Challenge ~= Isaac.GetChallengeIdByName("Case Study - Guppy's Tail") then return end

    SFXManager():Stop(SoundEffect.SOUND_DOOR_HEAVY_CLOSE)
    SFXManager():Stop(SoundEffect.SOUND_DOOR_HEAVY_OPEN)
    Game():GetHUD():SetVisible(false)

    f:DrawStringScaled("(Move into a room with combat to begin)", 5, 0, 1, 1, KColor(1,1,1,1), 0, false)

    f:DrawStringScaled("Trial: " .. (trialMax - trialNum) .. "/" .. trialMax, 5, 10, 1, 1, KColor(1,1,1,1), 0, false)
    f:DrawStringScaled("Repeat Count: " .. (currRepeat) .. "/" .. repeatCount, 5, 17, 1, 1, KColor(1,1,1,1), 0, false)
    f:DrawStringScaled("Environment: " .. EnvText[currentEnv], 5, 24, 1, 1, KColor(1,1,1,1), 0, false)
    

    f:DrawStringScaled("TAB to show charts", centerPos.X*2 - 5, 0, 1, 1, KColor(1,1,1,1), 1, false)
    f:DrawStringScaled("Q to toggle chart type", centerPos.X*2 - 5, 10, 1, 1, KColor(1,1,1,1), 1, false)
    f:DrawStringScaled("Z to reload the script", centerPos.X*2 - 5, 20, 1, 1, KColor(1,1,1,1), 1, false)

    local keys = {}
    local vals = {}

    local sorted_agg = {}
    local filter_count = 0

    for pick,num in pairs(pickup_keys) do
        table.insert(keys, pick)
        table.insert(vals, num)
    end

    local totalNum = table.reduce(vals, function(a,b)
        return a+b
    end)

    table.sort(keys, function(a,b)
        return pickup_keys[a] > pickup_keys[b]
    end)

    for _,key in ipairs(keys) do
        table.insert(sorted_agg, {key = key, val = pickup_keys[key]})
    end

    for y, pick in ipairs(sorted_agg) do
        -- print(pick.key, pick.val)
        local extract = string.match(pick.key,"(%d+)%D+(%d+)")
        local percent = math.floor(pick.val/(totalNum)*100)
        local readout = pick.val .. " (" .. ((percent == 0 and pick.val ~= 0) and "less than 1" or percent) .. "%)"
        f:DrawStringScaled(name_dict[pick.key] .. " : " .. readout, 6, 35 + 7*y, 1, 1, KColor(0,0,0,((percent == 0 and pick.key ~= "30-1") and pick.val ~= 0) and 0.2 or 1), 0, false)

        local main_color = color_dict[tonumber(extract)] and color_dict[tonumber(extract)] or KColor(1,1,1,1)

        main_color.Alpha = (percent == 0 and pick.val ~= 0) and 0.2 or 1
        
        f:DrawStringScaled(name_dict[pick.key] .. " : " .. readout, 5, 34 + 7*y, 1, 1, main_color, 0, false)
        y = y + 1
    end

    for _,e in ipairs(Isaac.GetRoomEntities()) do

        if e.Type == EntityType.ENTITY_PICKUP and e.Color.R ~= 0 then
            local p = e:ToPickup()
            if
            (e.Variant >= PickupVariant.PICKUP_CHEST and e.Variant <= PickupVariant.PICKUP_LOCKEDCHEST)
            or e.Variant == PickupVariant.PICKUP_GRAB_BAG
            or e.Variant == PickupVariant.PICKUP_REDCHEST
            then
                if e.Variant ~= PickupVariant.PICKUP_LOCKEDCHEST and e.Variant ~= PickupVariant.PICKUP_REDCHEST then
                    p:TryOpenChest(Isaac.GetPlayer(0))
                end
            else
                e:Remove()
            end
            e.Color = Color(0,1,1,0.2)
            local vv = e.Variant
            local ss = e.SubType
            if vv == 300 or vv == 100 or vv == 350 or vv == 70 then
                ss = 0
            end
            local concat = ""
            if lumpSum then
                if (vv > 50 and vv <= 60) or vv == 360 then
                    vv = 50
                end
                for i=0,20,1 do
                    concat = vv .. "-" .. i
                    if name_dict[concat] then break end
                end
            else
                concat = vv .. "-" .. ss
            end

            table.insert(pickup_agg, {v = vv, s = ss})
            
            if pickup_keys[concat] then
                pickup_keys[concat] = pickup_keys[concat] + 1
            else
                pickup_keys[concat] = 1
            end
        elseif (e:ToPlayer() == nil) then
            if not (e.Variant == PickupVariant.PICKUP_LOCKEDCHEST and
            ((pickup_keys["30-1"] == 0 and not Isaac.GetPlayer(0):HasCollectible(CollectibleType.COLLECTIBLE_PAY_TO_PLAY)) or
            (pickup_keys["20-1"] == 0 and Isaac.GetPlayer(0):HasCollectible(CollectibleType.COLLECTIBLE_PAY_TO_PLAY)) or
            e.SubType == 1)) then
                e:Remove()
            end
        end

        if e.Type == EntityType.ENTITY_PICKUP then
            if e.Variant == PickupVariant.PICKUP_LOCKEDCHEST and
            ((pickup_keys["30-1"] > 0 and not Isaac.GetPlayer(0):HasCollectible(CollectibleType.COLLECTIBLE_PAY_TO_PLAY)) or
            (pickup_keys["20-1"] > 0 and Isaac.GetPlayer(0):HasCollectible(CollectibleType.COLLECTIBLE_PAY_TO_PLAY))) then
                if not Isaac.GetPlayer(0):HasTrinket(TrinketType.TRINKET_PAPER_CLIP) and e.SubType == 1 then
                    pickup_keys["30-1"] = pickup_keys["30-1"] - 1
                end
                if Isaac.GetPlayer(0):HasCollectible(CollectibleType.COLLECTIBLE_PAY_TO_PLAY) and e.SubType == 1 then
                    pickup_keys["20-1"] = pickup_keys["20-1"] - 1
                end
                e:ToPickup():TryOpenChest(Isaac.GetPlayer(0))
            elseif e.Variant == PickupVariant.PICKUP_GRAB_BAG then
                e.Position = Isaac.GetPlayer(0).Position
            elseif e.Variant == PickupVariant.PICKUP_COLLECTIBLE then
                e:Remove()
            end
        end

        Isaac.GetPlayer(0):AddHearts(2)

    end

    if Input.IsActionTriggered(ButtonAction.ACTION_PILLCARD, 0) then
        disp_chart = (disp_chart + 1) % 2
    end
    if Input.IsButtonTriggered(Keyboard.KEY_Z, 0) then
        Isaac.ExecuteCommand("luamod guppys tail test")
    end

    local showPie = function()
        crust.Scale = Vector(1,1)/5
        line.Scale = Vector(40,0.5)
        line.Color = Color(0,0,0,0.4)

        local piePos = Vector(350,200)

        local angle = 0
        for y, pick in ipairs(sorted_agg) do
            local percent = y ~= #sorted_agg and math.floor(math.floor(pick.val/(totalNum)*360) + 0.5) or 360 - angle
            local realPercent = math.floor(pick.val/(totalNum)*100 + 0.5)
            local extract = string.match(pick.key,"(%d+)%D+(%d+)")
            local KC = color_dict[tonumber(extract)] ~= nil and color_dict[tonumber(extract)] or KColor(1,1,1,1)
            local readout = pick.val .. " (" .. ((realPercent == 0 and pick.val ~= 0) and "less than 1" or realPercent) .. "%)"
            local rotPos = piePos + Vector.FromAngle(angle + percent/2) * 55

            if realPercent > 2 then
                f:DrawStringScaled(realPercent .. "%", rotPos.X-2+1, rotPos.Y-8+1, 1, 1, KColor(0,0,0,1), 0, false)
                f:DrawStringScaled(realPercent .. "%", rotPos.X-2, rotPos.Y-8, 1, 1, y == 1 and KColor(0,1,0,1) or KColor(1,1,1,1), 0, false)
            end

            crust.Color = Color(KC.Red, KC.Green, KC.Blue, 1)
            if percent > 1 then
                crust:ReplaceSpritesheet(0,"gfx/guppy/crusts/crust" .. percent .. ".png")
                crust:LoadGraphics()
            end
            crust.Rotation = angle
            crust:Render(piePos)

            angle = angle + percent
        end

        for y, pick in ipairs(sorted_agg) do
            local percent = math.floor(math.floor(pick.val/(totalNum)*360) + 0.5)

            if percent > 3 then
                line.Rotation = angle
                line:Render(piePos)
            end


            angle = angle + percent
        end
    end

    local showLine = function()

        local plot_pos = Vector(150,215)

        line.Color = Color(0,0,0,1)
        line.Scale = Vector(60,0.5)
        line.Rotation = -90
        line:Render(plot_pos + Vector(0,2))

        line.Scale = Vector(100,0.5)
        line.Rotation = 0
        line:Render(plot_pos + Vector(0,1))

        f:DrawStringScaled(x_scale, plot_pos.X+100, plot_pos.Y, 0.5,0.5, KColor(1,1,1,1), 1, true)

        local preVal = -1
        local unit = math.max(math.min(y_scale, 10), 1)
        for i=0,unit,1 do
            local pc = i/unit
            local val = math.floor((y_scale)*pc)
            local floorPc = val/y_scale
            if val ~= preVal then
                f:DrawStringScaled(val, plot_pos.X - 6, plot_pos.Y - 50*floorPc - 4, 0.5,0.5, KColor(1,1,1,1), 1, true)
                line.Color = Color(0,0,0,1)
                line.Scale = Vector(5,0.5)
                line.Rotation = 0
                line:Render(plot_pos - Vector(2.5, 50*floorPc))
            end
            preVal = val
        end

        local useMe = {}

        if filter_count > 1 then
            useMe = {table.unpack(sorted_agg,1,filter_count)}
        else
            useMe = sorted_agg
        end

        local skipCount = math.ceil(x_scale/50)

        for _,lineIdx in pairs(useMe) do
            local lineKey = lineIdx.key
            local plot_space = key_graph[lineKey]

            if plot_space and plot_space[#plot_space] > 0 then
                y_scale = math.max(y_scale, plot_space[#plot_space])
                x_scale = math.max(x_scale, #plot_space)
            end

            -- Render line

            local ii = 0

            for i=1,trialMax,skipCount do
                ii = i

                if not plot_space or #plot_space < i then break end

                if plot_space[i] > 0 then
                    -- y_scale = math.max(y_scale, plot_space[i])
                    -- x_scale = math.max(x_scale, i)

                    local pv = Vector(i*100/x_scale, -plot_space[i]/y_scale*50)
                    local prev = Vector((i-skipCount)*100/x_scale, -(plot_space[i-skipCount] ~= nil and plot_space[i-skipCount] or plot_space[i])/y_scale*50)

                    local extract = string.match(lineKey,"(%d+)%D+(%d+)")
                    local KC = color_dict[tonumber(extract)] ~= nil and color_dict[tonumber(extract)] or KColor(1,1,1,1)

                    line.Color = Color(KC.Red, KC.Green, KC.Blue, 1)

                    if key_graph["100-0"][i] > key_graph["100-0"][i == 1 and i or i-skipCount] then
                        line.Color = Color(0.5,1,0.5,1)
                    end

                    line.Scale = Vector((prev - pv):Length(), 0.5)
                    line.Rotation = (prev - pv):GetAngleDegrees()
                    line:Render(plot_pos + pv)
                end
            end

            ii = ii - skipCount

            if plot_space and ii ~= #plot_space then
                local pv = Vector(ii*100/x_scale, -plot_space[ii]/y_scale*50)
                local next = Vector((#plot_space)*100/x_scale, -(plot_space[#plot_space] ~= nil and plot_space[#plot_space] or plot_space[#plot_space])/y_scale*50)

                local extract = string.match(lineKey,"(%d+)%D+(%d+)")
                local KC = color_dict[tonumber(extract)] ~= nil and color_dict[tonumber(extract)] or KColor(1,1,1,1)

                line.Color = Color(KC.Red, KC.Green, KC.Blue, 1)

                line.Scale = Vector((pv - next):Length(), 0.5)
                line.Rotation = (pv - next):GetAngleDegrees()
                line:Render(plot_pos + next)
            end


        end

        -- Render points of interest
        for i=1,trialMax,1 do
            if not plot_space or #plot_space < i then break end
            local pv = Vector(i*100/x_scale, -plot_space[i]/y_scale*50)
            if key_graph["100-0"][i] > key_graph["100-0"][i == 1 and i or i-skipCount] then
                pixel.Color = Color(0,1,0,1)
                pixel.Scale = Vector(2,2)
                pixel:Render(plot_pos + pv - Vector(1,1))
            end
        end
    end

    if (Input.IsActionPressed(ButtonAction.ACTION_MAP, 0) and not show_chart) or (show_chart and not Input.IsActionPressed(ButtonAction.ACTION_MAP, 0)) then
        showPie()
        showLine()
    end

end

function mod:postPickupSelect(pickup, offset)

    -- room_count[#room_count] = room_count[#room_count] + 1
    -- local strs = ""
    -- for _,r in ipairs(room_count) do
    --     strs = strs .. r .. ","
    -- end
    -- print(strs)

    if Game().Challenge ~= Isaac.GetChallengeIdByName("Case Study - Guppy's Tail") then return end

    if trialNum == 0 and currentEnv < 9 then
        trialNum = trialMax

        y_scale = 1
        x_scale = 20

        pickup_agg = {}
        pickup_keys = {
            ["30-1"] = (currentEnv == EnvNames.KEY_ADV and 3 or (currentEnv == EnvNames.MOMS_KEY and 2 or (currentEnv == EnvNames.GILDED_KEY and 1 or 0))),
            ["20-1"] = 0
        }
        key_graph = {}

        for _,e in ipairs(Isaac.GetRoomEntities()) do
            if e.Type == EntityType.ENTITY_PICKUP and e.Variant == PickupVariant.PICKUP_LOCKEDCHEST then
                e:Remove()
            end
        end
        
        if currRepeat >= repeatCount then
            if hasTail then
                y_scale = 1
                currentEnv = currentEnv + 1
                hasTail = not hasTail
                removeAll()
                if currentEnv == EnvNames.KEY_ADV then
                    
                elseif currentEnv == EnvNames.MOMS_KEY then
                    Isaac.GetPlayer(0):AddCollectible(CollectibleType.COLLECTIBLE_MOMS_KEY)
                elseif currentEnv == EnvNames.PAPER_CLIP then
                    Isaac.GetPlayer(0):AddTrinket(TrinketType.TRINKET_PAPER_CLIP)
                elseif currentEnv == EnvNames.DAEMONS_TAIL then
                    Isaac.GetPlayer(0):AddTrinket(TrinketType.TRINKET_DAEMONS_TAIL)
                elseif currentEnv == EnvNames.CONTRACT then
                    Isaac.GetPlayer(0):AddCollectible(CollectibleType.COLLECTIBLE_CONTRACT_FROM_BELOW)
                elseif currentEnv == EnvNames.RUSTED_KEY then
                    Isaac.GetPlayer(0):AddTrinket(TrinketType.TRINKET_RUSTED_KEY)
                elseif currentEnv == EnvNames.LUCKY_FOOT then
                    Isaac.GetPlayer(0):AddCollectible(CollectibleType.COLLECTIBLE_LUCKY_FOOT)
                elseif currentEnv == EnvNames.GILDED_KEY then
                    Isaac.GetPlayer(0):AddTrinket(TrinketType.TRINKET_GILDED_KEY)
                elseif currentEnv == EnvNames.LOTSA_LUCK then
                    Isaac.GetPlayer(0):AddCacheFlags(CacheFlag.CACHE_ALL)
                    Isaac.GetPlayer(0):EvaluateItems()
                end
            else
                hasTail = not hasTail
                Isaac.GetPlayer(0):AddCollectible(CollectibleType.COLLECTIBLE_GUPPYS_TAIL)
            end
            currRepeat = 0
            textCorpus = textCorpus .. "\n"
        end

        -- CONTROL = 1,
        -- KEY_ADV = 2,
        -- MOMS_KEY = 3,
        -- PAPER_CLIP = 4,
        -- DAEMONS_TAIL = 5,
        -- CONTRACT = 6,
        -- RUSTED_KEY = 7,
        -- LUCKY_FOOT = 8,
        -- GILDED_KEY = 9,
        -- LOTSA_LUCK = 10

        mod:SaveData(textCorpus)
        currRepeat = currRepeat + 1

    end

    if trialNum > 0 then

        local nameList = {}
        for code,name in pairs(name_dict) do
            table.insert(nameList, {code = code, name = name, value = pickup_keys[code] ~= nil and pickup_keys[code] or 0})
        end
        table.sort(nameList, function(a,b)
            return a.code < b.code
        end)


        if trialNum == trialMax then
            textCorpus = textCorpus .. "\nCurrent Env,Has Tail?,Trial #,Repeat #,"
            for i,data in pairs(nameList) do
                textCorpus = textCorpus .. data.name .. ","
            end
            textCorpus = textCorpus .. "\n"
        end

        textCorpus = textCorpus .. EnvText[currentEnv] .. "," .. (hasTail and "True" or "False") .. "," .. (trialMax - trialNum) .. "," .. currRepeat .. ","
        for i,data in pairs(nameList) do
            textCorpus = textCorpus .. data.value .. ","
        end
        textCorpus = textCorpus .. "\n"

        if breakpoints then
            for _,b in ipairs(breaks) do
                if trialNum == (trialMax - b) then
                    for _,e in ipairs(Isaac.GetRoomEntities()) do
                        if e.Type == EntityType.ENTITY_PICKUP and e.Variant == PickupVariant.PICKUP_LOCKEDCHEST then
                            e:Remove()
                        end
                    end
                end
            end
        end
        
        for key,name in pairs(name_dict) do
            if not key_graph[key] then
                key_graph[key] = {}
            end
            table.insert(key_graph[key], (pickup_keys[key] ~= nil and pickup_keys[key] or 0) + 0)
        end
    Isaac.GetPlayer(1):UseActiveItem(CollectibleType.COLLECTIBLE_D7, 3)

    trialNum = trialNum - 1

    end

    return nil
end

function mod:onNewLevel()
    table.insert(room_count, 0)
end

function mod:evalItems(player, flags)
    if Game().Challenge ~= Isaac.GetChallengeIdByName("Case Study - Guppy's Tail") then return end
    if currentEnv == EnvNames.LOTSA_LUCK then
        player.Luck = 10
    else
        player.Luck = 0
    end
end

mod:AddCallback(ModCallbacks.MC_POST_UPDATE, mod.onUpdate)
mod:AddCallback(ModCallbacks.MC_POST_RENDER, onRender)
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.postPickupSelect)
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, mod.onNewLevel)
mod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, mod.evalItems)